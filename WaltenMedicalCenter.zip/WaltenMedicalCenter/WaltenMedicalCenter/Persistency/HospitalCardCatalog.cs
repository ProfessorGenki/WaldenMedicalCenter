﻿namespace WaltenMedicalCenter.Persistency
{
    public class HospitalCardCatalog
    {
        public HospitalCardCatalog()
        {
            
        }
    }
}