﻿namespace WaltenMedicalCenter.Persistency
{
    public class RelativeCatalog
    {
        public RelativeCatalog()
        {

        }
    }
}