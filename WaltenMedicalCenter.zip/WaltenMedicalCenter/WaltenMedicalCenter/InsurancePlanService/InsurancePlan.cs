﻿namespace WaltenMedicalCenter.InsurancePlanService
{
    public class InsurancePlan
    {
        public int SSN { get; set; }
        public string Provider { get; set; }
        public string Plan { get; set; }
        public string Validtil { get; set; }


    }
}
